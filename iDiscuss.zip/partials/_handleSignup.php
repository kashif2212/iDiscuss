<?php
$showError = "false";
if ($_SERVER["REQUEST_METHOD"]=="POST") {
    include '_dbconnect.php';
    // $user_email = $_POST['signupEmail'];
    if (isset($_POST['signupEmail'])) {
        $user_email = $_POST['signupEmail'];
    }
    if (isset($_POST['signupPassword'])) {
        $pass = $_POST['signupPassword'];
    }
    if (isset($_POST['signupcPassword'])) {
        $cpass = $_POST['signupcPassword'];
    }
    //     $pass = $_POST['signupPassword'];
    // $cpass = $_POST['signupcPassword'];

    //check whether this email exist
    if (!empty($user_email)) 
    {
            $existSql = "select * from `users` where user_email = '$user_email'";
        
        // $existSql = "select * from `users` where user_email = '$user_email'";
        $result = mysqli_query($conn,$existSql);
        $numRows = mysqli_num_rows($result);

        if ($numRows>0) {
            // $showErrorunmatchedpassword = true;
            $showError = "Email already in use";
        }
        else {
            if ($pass == $cpass) {
                $hash = password_hash($pass,PASSWORD_DEFAULT);
                $sql = "INSERT INTO `users` (`user_email`, `user_pass`, `timestamp`) VALUES ('$user_email', '$hash ', current_timestamp())";
                $result = mysqli_query($conn,$sql);
                if ($result) {
                    $showAlert = true;
                    header("Location: /forum/index.php?signupsuccess=true");
                    exit();
                }
            } else {
                $showError = "passwords do not match";
            }
        }
        header("Location: /forum/index.php?signupsuccess=false&error=$showError");
    }
}
?>