<div class="container-fluid text-center bg-dark text-light ">
    <p class="mb-0">Copyright iDiscuss coding Forums 2022 | All rights reserved</p>
</div>